// import React from 'react'
// import BasicLayout from '../layouts/BasicLayout'
// import ReservationComponent from '../components/menus/ReservationComponent'


// const Cart = () => {
//   return (
//     <BasicLayout>
//         <ReservationComponent />
//     </BasicLayout>
//   )
// }

// export default Cart