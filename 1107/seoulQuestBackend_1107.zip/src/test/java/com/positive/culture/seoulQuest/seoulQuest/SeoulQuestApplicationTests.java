package com.positive.culture.seoulQuest.seoulQuest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeoulQuestApplicationTests {

	@Test
	void contextLoads() {
	}

}
