import React from 'react'

const AdminProductComponents = () => {
    return <div>AdminProductComponents</div>
}

export default AdminProductComponents    