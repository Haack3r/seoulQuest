package com.positive.culture.seoulQuest.repository;

import com.positive.culture.seoulQuest.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}
