import React from 'react'

const AboutTourPage = () => {
  return (
    <div>AboutTourPage</div>
  )
}

export default AboutTourPage