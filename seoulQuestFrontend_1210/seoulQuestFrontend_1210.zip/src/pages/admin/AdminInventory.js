import React from 'react'
import AdminInventory from '../../components/admin/AdminInventoryComponents'

const AdminInventoryPage = () => {
    return (
        <div className='w-full'><AdminInventory /></div>
    )
}

export default AdminInventoryPage