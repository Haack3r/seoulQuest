import React from 'react'
import AdminDelivery from '../../components/admin/AdminDeliveryComponents'

const AdminDeliveryPage = () => {
    return (
        <div className='w-full'><AdminDelivery /></div>
    )
}

export default AdminDeliveryPage