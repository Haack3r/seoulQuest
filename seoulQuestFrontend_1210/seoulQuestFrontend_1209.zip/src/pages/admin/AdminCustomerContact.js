import React from 'react'
import AdminCustomerContact from '../../components/admin/AdminCustomerContactComponents'

const AdminCustomerContactPage = () => {
    return (
        <div className='w-full'><AdminCustomerContact /></div>
    )
}

export default AdminCustomerContactPage