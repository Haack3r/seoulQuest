import React from 'react'
import AdminExchange from "../../components/admin/AdminExchangeComponents"

const AdminExchangePage = () => {
    return (
        <div className='w-full'><AdminExchange /></div>
    )
}

export default AdminExchangePage