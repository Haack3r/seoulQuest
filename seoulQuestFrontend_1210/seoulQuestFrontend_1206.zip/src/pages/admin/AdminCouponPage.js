import React from 'react'
import AdminCouponComponents from '../../components/admin/AdminCouponComponents'


const AdminCouponPage = () => {
    return (
        <div className='w-full'>
            <AdminCouponComponents />
        </div>
    )
}

export default AdminCouponPage