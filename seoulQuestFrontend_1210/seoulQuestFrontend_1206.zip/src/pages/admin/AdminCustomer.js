import React from 'react'
import AdminCustomer from "../../components/admin/AdminCustomerComponents"

const AdminCustomerPage = () => {
    return (
        <div className='w-full'><AdminCustomer /></div>
    )
}

export default AdminCustomerPage