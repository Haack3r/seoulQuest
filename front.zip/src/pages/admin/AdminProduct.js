import React from 'react'
import AdminProductComponent from '../../components/admin/AdminProductComponents'


const AdminProductPage = () => {
    return (
        <div className='w-full'>
            <AdminProductComponent />
        </div>
    )
}

export default AdminProductPage