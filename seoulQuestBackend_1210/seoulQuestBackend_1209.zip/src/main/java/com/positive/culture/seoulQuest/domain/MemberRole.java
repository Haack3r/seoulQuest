package com.positive.culture.seoulQuest.domain;

public enum MemberRole {
    USER, ADMIN; // 숫자 (USER = 0, ADMIN = 1, MANAGER = 2)
}
