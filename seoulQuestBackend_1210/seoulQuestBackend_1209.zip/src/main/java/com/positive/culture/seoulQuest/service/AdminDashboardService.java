package com.positive.culture.seoulQuest.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.positive.culture.seoulQuest.dto.DashboardStatisticsDTO;
import com.positive.culture.seoulQuest.dto.TopReservedTourDTO;
import com.positive.culture.seoulQuest.dto.TopSellingProductDTO;
import com.positive.culture.seoulQuest.repository.ProductPaymentItemRepository;
import com.positive.culture.seoulQuest.repository.ReservationItemRepository;
import com.positive.culture.seoulQuest.repository.TourPaymentItemRepository;

import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminDashboardService {

    private final ProductPaymentItemRepository productPaymentItemRepository;
    private final TourPaymentItemRepository tourPaymentItemRepository;
    private final ReservationItemRepository reservationItemRepository;

    @Transactional(readOnly = true)
    public DashboardStatisticsDTO getDashboardStatistics() {
        Long productRevenue = productPaymentItemRepository.calculateTotalRevenue();
        Long tourRevenue = tourPaymentItemRepository.calculateTotalRevenue();
        Long totalRevenue = (productRevenue != null ? productRevenue : 0L) +
                          (tourRevenue != null ? tourRevenue : 0L);
        Long tourCount = reservationItemRepository.countTodayTours();
        Long productCount = productPaymentItemRepository.countTodayProducts();

        return DashboardStatisticsDTO.builder()
                .totalRevenue(totalRevenue != null ? totalRevenue : 0L)
                .tourCount(tourCount != null ? tourCount : 0L)
                .productCount(productCount != null ? productCount : 0L)
                .build();
    }

    @Transactional(readOnly = true)
    public List<TopSellingProductDTO> getTopSellingProducts() {
        List<Object[]> results = productPaymentItemRepository.findTopSellingProducts();
        return results.stream()
            .map(result -> TopSellingProductDTO.builder()
                .productId((Long) result[0])
                .productName((String) result[1])
                .salesCount(((Number) result[2]).intValue())
                .build())
            .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TopReservedTourDTO> getTopReservedTours() {
        List<Object[]> results = tourPaymentItemRepository.findTopReservedTours();
        return results.stream()
            .map(result -> TopReservedTourDTO.builder()
                .tourId((Long) result[0])
                .tourName((String) result[1])
                .reservationCount(((Number) result[2]).intValue())
                .build())
            .collect(Collectors.toList());
    }
}