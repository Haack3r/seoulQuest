package com.positive.culture.seoulQuest.repository;

import com.positive.culture.seoulQuest.domain.ProductPaymentItem;
import com.positive.culture.seoulQuest.domain.TourPayment;
import com.positive.culture.seoulQuest.domain.TourPaymentItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TourPaymentItemRepository extends JpaRepository<TourPaymentItem, Long> {
    // 결제된 tour 들의 목록을 찾음
    List<TourPaymentItem> findByTourPaymentIn(List<TourPayment> payments);

    @Query("SELECT DISTINCT t.tour.tno, t.tour.tname, t.tprice, SUM(t.tPaymentQty) AS totalReservations " +
            "FROM TourPaymentItem t " +
            "GROUP BY t.tour.tno, t.tour.tname, t.tprice " +
            "ORDER BY totalReservations DESC")
    List<Object[]> findTopReservedTours();

    List<TourPaymentItem> findByTourPayment(TourPayment tourPayment);

    @Query("SELECT SUM(tpi.tprice * tpi.tPaymentQty) FROM TourPaymentItem tpi")
    Long calculateTotalRevenue();

    @Query("SELECT COUNT(tpi) FROM TourPaymentItem tpi WHERE DATE(tpi.tourPayment.paymentDate) = CURRENT_DATE")
    Long countTodayTours();

    @Query("SELECT DISTINCT t.tour.tno, t.tour.tname, SUM(t.tPaymentQty) AS totalReservations, " +
            "SUM(t.tprice * t.tPaymentQty) AS totalRevenue " +
            "FROM TourPaymentItem t " +
            "WHERE DATE(t.tourPayment.paymentDate) >= CURRENT_DATE - 7 " + // 최근 7일 데이터
            "GROUP BY t.tour.tno, t.tour.tname " +
            "ORDER BY totalRevenue DESC") // 매출액 기준으로 정렬
    List<Object[]> getWeeklyTopRevenueTours();
}
