package com.positive.culture.seoulQuest.util;

public class CustomJWTException extends RuntimeException{
    public CustomJWTException(String message) {
        super(message);
    }
}
