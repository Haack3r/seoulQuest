import React from 'react'
import AdminDeliveryFee from "../../components/admin/AdminDeliveryFeeComponents"

const AdminDeliveryFeePage = () => {
    return (
        <div className='w-full'><AdminDeliveryFee /></div>
    )
}

export default AdminDeliveryFeePage