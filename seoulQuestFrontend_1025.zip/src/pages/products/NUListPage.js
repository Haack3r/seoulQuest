import React from 'react'
import NUListComponent from '../../components/products/NUListComponent'

const NUListPage = () => {
    
  return (
    <div className='p-4 w-full bg-white'>
        {/* <ListImage /> */}
        <NUListComponent />
    </div>
  )
}

export default NUListPage