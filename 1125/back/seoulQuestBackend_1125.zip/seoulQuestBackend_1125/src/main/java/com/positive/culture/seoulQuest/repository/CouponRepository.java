package com.positive.culture.seoulQuest.repository;

import com.positive.culture.seoulQuest.domain.Coupon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CouponRepository extends JpaRepository<Coupon,Long> {

}
