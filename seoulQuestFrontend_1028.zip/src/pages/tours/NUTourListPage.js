import React from 'react'
import NUTourListComponent from '../../components/tours/NUTourListComponent'
import MainImage from './../../layouts/MainImage';
import TourImage from '../../layouts/TourImage';
import AboutToursComponent from '../../components/tours/AboutToursComponent ';

const NUTourListPage = () => {
  return (
    <div className='p-4 w-full' style={{ backgroundColor: '#E2DCD5' }}>
          <TourImage />
          <AboutToursComponent />
        <NUTourListComponent/>
    </div>
  )
}

export default NUTourListPage