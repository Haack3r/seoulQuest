import React from 'react'
import AdminDeliveryCost from "../../components/admin/AdminDeliveryCostComponents"

const AdminDeliveryCostPage = () => {
    return (
        <div className='w-full'><AdminDeliveryCost /></div>
    )
}

export default AdminDeliveryCostPage