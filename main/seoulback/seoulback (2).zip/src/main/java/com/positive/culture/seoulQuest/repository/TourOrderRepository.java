package com.positive.culture.seoulQuest.repository;

import com.positive.culture.seoulQuest.domain.TourOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TourOrderRepository extends JpaRepository<TourOrder,Long> {



}
