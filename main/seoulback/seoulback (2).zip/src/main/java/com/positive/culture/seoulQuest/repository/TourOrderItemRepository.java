package com.positive.culture.seoulQuest.repository;

import com.positive.culture.seoulQuest.domain.TourOrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TourOrderItemRepository extends JpaRepository<TourOrderItem,Long> {

}
