package com.positive.culture.seoulQuest.dto;

import lombok.*;

@Getter
@NoArgsConstructor
public class ContactRequestDTO {
    private String name;
    private String email;
    private String inquiry;
    
}
